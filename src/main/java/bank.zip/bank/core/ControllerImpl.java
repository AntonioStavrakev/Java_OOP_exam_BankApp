package bank.core;

public class ControllerImpl implements Controller {
    @Override
    public String addBank(String type, String name) {
        return null;
    }

    @Override
    public String addLoan(String type) {
        return null;
    }

    @Override
    public String returnedLoan(String bankName, String loanType) {
        return null;
    }

    @Override
    public String addClient(String bankName, String clientType, String clientName, String clientID, double income) {
        return null;
    }

    @Override
    public String finalCalculation(String bankName) {
        return null;
    }

    @Override
    public String getStatistics() {
        return null;
    }
}
