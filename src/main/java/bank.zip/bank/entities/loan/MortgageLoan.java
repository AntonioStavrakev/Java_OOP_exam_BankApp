package bank.entities.loan;

public class MortgageLoan extends BaseLoan{
    protected MortgageLoan() {
        super(3, 50000);
    }
}
