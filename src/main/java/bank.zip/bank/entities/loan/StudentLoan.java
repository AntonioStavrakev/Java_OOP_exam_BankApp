package bank.entities.loan;

public class StudentLoan extends BaseLoan{
    protected StudentLoan() {
        super(1, 10000);
    }
}
